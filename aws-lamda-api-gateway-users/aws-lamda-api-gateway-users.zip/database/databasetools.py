import json
import psycopg2


db_user = "postgres"
db_pass = "Admin123456"
db_host = "usuarios-db.czrjrjfko82t.us-east-1.rds.amazonaws.com"
db_port = "5432"
db_database = "usuarios-db"
    
connection = psycopg2.connect(user=db_user, password=db_pass,
                                  host=db_host, port=db_port,
                                  database=db_database)

class DataBase():

    def call_function(self,args):
        try:
            cursor = connection.cursor()
            query = "select * from cat_estatus;"
            cursor.execute(query)
            records = cursor.fetchall()

            return records
        except Exception as e:
            connection.close()
            return json.dumps({"Error" : "call_function", "Exception": "Erro {}".format(e), "statusCode": 404 })