create table persona(
	id_persona serial primary key,
	nombre varchar(50)NOT NULL,
	apaterno varchar(50)NOT NULL,
	amaterno varchar(50) NOT NULL,
	sueldo decimal NOT NULL,
	id_beneficiario integer NOT NULL,
	id_sexo int NOT NULL,
	fecha_contrato date NOT NULL,
	usuario_creacion integer NOT NULL,
	usuario_modificacion integer DEFAULT NULL,
	fecha_creacion TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
	fecha_modificacion TIMESTAMP WITH TIME ZONE DEFAULT NULL, 
	estado integer NOT NULL DEFAULT 1,
	CONSTRAINT fk_beneficiario
      FOREIGN KEY(id_beneficiario) 
	  REFERENCES beneficiario(id_beneficiario)
	  ON DELETE SET NULL,
	CONSTRAINT fk_id_sexo
      FOREIGN KEY(id_sexo) 
	  REFERENCES cat_sexo(id_sexo)
	  ON DELETE SET NULL
);