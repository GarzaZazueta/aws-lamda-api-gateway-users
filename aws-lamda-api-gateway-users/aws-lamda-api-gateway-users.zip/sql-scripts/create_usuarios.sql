create table usuarios(
	id_usuario serial primary key,
	username text NOT NULL,
	userpass text NOT NULL,
	id_puesto integer NOT NULL,
	id_permiso integer NOT NULL,
	id_estatus integer NOT NULL,
	usuario_creacion integer NOT NULL,
	usuario_modificacion integer DEFAULT NULL,
	fecha_creacion TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
	fecha_modificacion TIMESTAMP WITH TIME ZONE DEFAULT NULL, 
	estado integer NOT NULL DEFAULT 1,
	CONSTRAINT fk_id_puesto
      FOREIGN KEY(id_puesto) 
	  REFERENCES cat_puestos(id_puesto)
	  ON DELETE SET NULL,
	CONSTRAINT fk_id_permiso
      FOREIGN KEY(id_permiso) 
	  REFERENCES cat_permisos(id_permiso)
	  ON DELETE SET NULL,
	CONSTRAINT fk_id_estatus
      FOREIGN KEY(id_estatus) 
	  REFERENCES cat_estatus(id_estatus)
	  ON DELETE SET NULL
);