import json
import psycopg2

def hello(event, context):
    body = {
        "message": "Prueba deploy serveless",
        "input": event,
    }

    response = {"statusCode": 200, "body": json.dumps(body)}
    return response

def alta_usuarios(event, context):
    try:
        arg = json.loads(event["body"]) 
        response = {"statusCode": 200, "body": json.dumps(arg)}
        return response

    except Exception as e:
            return json.dumps({"Error" : "alta_usuarios", "Exception": "Erro {}".format(e), "statusCode": 404, "event": event })


    
